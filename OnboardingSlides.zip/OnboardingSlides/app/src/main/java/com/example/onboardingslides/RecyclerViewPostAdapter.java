package com.example.onboardingslides;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.onboardingslides.Retrofit.Post;

import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;

public class RecyclerViewPostAdapter extends RecyclerView.Adapter<RecyclerViewPostAdapter.MyViewHolder>implements Filterable {
   List<Post>list;
    List<Post> listFull;
    Context context;

    public RecyclerViewPostAdapter(List<Post> list, Context context) {
        this.list = list;
        this.context = context;
        listFull=new ArrayList<>(list);
    }


    @NonNull
    @Override
    public RecyclerViewPostAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_post,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewPostAdapter.MyViewHolder holder, int position) {
        holder.userID.setText(list.get(position).getUserId()+"");
        holder.id.setText(list.get(position).getId()+"");
        holder.title.setText(list.get(position).getTitle());
        holder.body.setText(list.get(position).getBody());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public Filter getFilter() {
        return FilterUser;
    }
    private Filter FilterUser=new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            String searchText=charSequence.toString().toLowerCase();
            List<Post>tempList=new ArrayList<>();
            if (searchText.length()==0 || searchText.isEmpty())
            {
                tempList.addAll(listFull);
            } else
            {
                for (Post item:listFull)
                {
                    if (item.getTitle().toLowerCase().contains(searchText))
                    {
                        tempList.add(item);
                    }
                }
            }
            FilterResults filterResults=new FilterResults();
            filterResults.values=tempList;
            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            list.clear();
            list.addAll((Collection<? extends Post>) filterResults.values);
            notifyDataSetChanged();

        }
    };

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView userID,id,title,body;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            userID=itemView.findViewById(R.id.userId);
            id=itemView.findViewById(R.id.id);
            title=itemView.findViewById(R.id.titlesp);
            body=itemView.findViewById(R.id.body);
        }
    }
}
