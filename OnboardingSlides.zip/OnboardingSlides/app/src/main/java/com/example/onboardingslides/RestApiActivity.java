package com.example.onboardingslides;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.onboardingslides.Retrofit.Post;
import com.example.onboardingslides.Retrofit.RetrofitInstance;
import com.example.onboardingslides.Retrofit.ServiceApi;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RestApiActivity extends AppCompatActivity {
    private Button checkIn;
    private Button checkOut;

    private SearchView searchView;

    RecyclerView recyclerView;
    List<Post> postList;
    RecyclerViewPostAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View windowDecorView = getWindow().getDecorView();
        windowDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        setContentView(R.layout.activity_rest_api);

        searchView =findViewById(R.id.searchView);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                adapter.getFilter().filter(s.toString());
                return false;
            }
        });

        checkIn = findViewById(R.id.checkIn);
        checkOut = findViewById(R.id.checkOut);

        checkIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {CheckInActivity();

            }
        });
        checkOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {CheckOutActivity();

            }
        });

        recyclerView = findViewById(R.id.recyclerView);
        postList = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ServiceApi serviceApi = RetrofitInstance.getRetrofit().create(ServiceApi.class);
        Call<List<Post>> call = serviceApi.getAllPost();
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                if (!response.isSuccessful()) {
                    return;
                }
                postList = response.body();
                adapter = new RecyclerViewPostAdapter(postList, RestApiActivity.this);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                Log.d("TAG", "onFailure:" + t.getLocalizedMessage());
            }
        });
    }
    public void CheckInActivity(){
        Intent intent = new Intent(RestApiActivity.this, CheckInActivity.class);
        startActivity(intent);
    }
    public void CheckOutActivity(){
        Intent intent = new Intent(RestApiActivity.this, CheckOutActivity.class);
        startActivity(intent);
    }
}