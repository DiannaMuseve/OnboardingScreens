package com.example.onboardingslides;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DashboardActivity extends AppCompatActivity {

    private Button checkIn;
    private Button checkOut;

    private SearchView searchView;

    RecyclerView recyclerView1;
    UserAdapter userAdapter;
    List<UserModel> userModelList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View windowDecorView = getWindow().getDecorView();
        windowDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        setContentView(R.layout.activity_dashboard);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayShowHomeEnabled(true);

        checkIn = findViewById(R.id.checkIn);
        checkOut = findViewById(R.id.checkOut);

        checkIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {SuccessfulActivity();

            }
        });
        checkOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {CheckoutActivity();

            }
        });


        searchView =findViewById(R.id.searchView);
        searchView.clearFocus();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);
                return true;
            }
        });


        recyclerView1 = findViewById(R.id.recyclerView1);
        setData();
        prepareRecyclerView();
    }

    private void filterList(String text) {
        List<UserModel>filteredList = new ArrayList<>();
        for (UserModel userModel : userModelList){
            if (userModel.getActualName1().toLowerCase().contains(text.toLowerCase())){
                filteredList.add(userModel);
            }
        }
        if (filteredList.isEmpty()){
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        } else {
            userAdapter.setFilteredList(filteredList);
        }
    }

    public void setData(){
        userModelList.add(new UserModel(R.drawable.leftarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.rightarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.rightarrow,"Name","Gerald Isaac", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.leftarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.leftarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.rightarrow,"Name","Gerald Isaac", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.leftarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.rightarrow,"Name","Dennis Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.leftarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));

    }


    public void prepareRecyclerView(){
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false);
        recyclerView1.setLayoutManager((linearLayoutManager));
        preAdapter();
    }

    public void preAdapter(){
        userAdapter = new UserAdapter(userModelList, this);
        recyclerView1.setAdapter(userAdapter);
    }

    public void SuccessfulActivity(){
        Intent intent = new Intent(DashboardActivity.this, CheckInActivity.class);
        startActivity(intent);
    }
    public void CheckoutActivity(){
        Intent intent = new Intent(DashboardActivity.this, CheckOutActivity.class);
        startActivity(intent);
    }

}