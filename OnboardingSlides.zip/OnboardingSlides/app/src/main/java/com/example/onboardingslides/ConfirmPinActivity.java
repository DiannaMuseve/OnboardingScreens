package com.example.onboardingslides;

import static androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG;
import static androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.Executor;

public class ConfirmPinActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int REQUEST_CODE = 101010;
    private Button btnContinue;
    private ImageView fingerprint;

    private Executor executor;
    private BiometricPrompt biometricPrompt;
    private BiometricPrompt.PromptInfo promptInfo;

    View view1, view2, view3, view4;
    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9;
    ImageButton btnx;

    ArrayList<String> numbers_list = new ArrayList<>();
    String passCode ="";
    String num1,num2,num3,num4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View windowDecorView = getWindow().getDecorView();
        windowDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        setContentView(R.layout.activity_confirm_pin);
        initializeComponents();

        btnContinue = findViewById(R.id.btnContinue);
        fingerprint = findViewById(R.id.fingerprint);


        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoggedActivity();
            }
        });
        BiometricManager biometricManager = BiometricManager.from(this);
        switch (biometricManager.canAuthenticate(BIOMETRIC_STRONG | DEVICE_CREDENTIAL)) {
            case BiometricManager.BIOMETRIC_SUCCESS:
                Log.d("MY_APP_TAG", "App can authenticate using biometrics.");
                break;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                Toast.makeText(this, "Fingerprint Sensor Not Exist", Toast.LENGTH_SHORT).show();
                break;
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                Toast.makeText(this, "Sensor Not Available", Toast.LENGTH_SHORT).show();
                break;
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                // Prompts the user to create credentials that your app accepts.
                final Intent enrollIntent = new Intent(Settings.ACTION_BIOMETRIC_ENROLL);
                enrollIntent.putExtra(Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                        BIOMETRIC_STRONG | DEVICE_CREDENTIAL);
                startActivityForResult(enrollIntent, REQUEST_CODE);
                break;
        }executor = ContextCompat.getMainExecutor(this);
        biometricPrompt = new BiometricPrompt(ConfirmPinActivity.this,
                executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode,
                                              @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                Toast.makeText(getApplicationContext(),
                        "Authentication error: " + errString, Toast.LENGTH_SHORT)
                        .show();
            }

            @Override
            public void onAuthenticationSucceeded(
                    @NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                startActivity(new Intent(ConfirmPinActivity.this, DashboardActivity.class));
                Toast.makeText(getApplicationContext(),
                        "Authentication succeeded!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(getApplicationContext(), "Authentication failed",
                        Toast.LENGTH_SHORT)
                        .show();
            }
        });

        promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Access Your Portal Quickly")
                .setSubtitle("Please Authenticate your biometric details")
                .setNegativeButtonText("Use Account Password")
                .build();

        // Prompt appears when user clicks "Log in".

        fingerprint.setOnClickListener(view -> {
            biometricPrompt.authenticate(promptInfo);
        });

    }

    private void initializeComponents() {
        view1 = findViewById(R.id.view1);
        view2 = findViewById(R.id.view2);
        view3 = findViewById(R.id.view3);
        view4 = findViewById(R.id.view4);

        btn0 = findViewById(R.id.btn0);
        btnx = findViewById(R.id.btnx);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);

        btn0.setOnClickListener(this);
        btnx.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn0:
                numbers_list.add("0");
                passNumber(numbers_list);
                break;
            case R.id.btnx:
                numbers_list.clear();
                passNumber(numbers_list);
                break;
            case R.id.btn1:
                numbers_list.add("1");
                passNumber(numbers_list);
                break;
            case R.id.btn2:
                numbers_list.add("2");
                passNumber(numbers_list);
                break;
            case R.id.btn3:
                numbers_list.add("3");
                passNumber(numbers_list);
                break;
            case R.id.btn4:
                numbers_list.add("4");
                passNumber(numbers_list);
                break;
            case R.id.btn5:
                numbers_list.add("5");
                passNumber(numbers_list);
                break;
            case R.id.btn6:
                numbers_list.add("6");
                passNumber(numbers_list);
                break;
            case R.id.btn7:
                numbers_list.add("7");
                passNumber(numbers_list);
                break;
            case R.id.btn8:
                numbers_list.add("8");
                passNumber(numbers_list);
                break;
            case R.id.btn9:
                numbers_list.add("9");
                passNumber(numbers_list);
                break;
        }
    }

    private void passNumber(ArrayList<String> numbers_list) {
        if (numbers_list.size() == 0){
            view1.setBackgroundResource(R.drawable.linesss);
            view2.setBackgroundResource(R.drawable.linesss);
            view3.setBackgroundResource(R.drawable.linesss);
            view4.setBackgroundResource(R.drawable.linesss);
        } else {
            switch (numbers_list.size()){
                case 1:
                    num1 = numbers_list.get(0);
                    view1.setBackgroundResource(R.drawable.pin_code);
                    break;
                case 2:
                    num2 = numbers_list.get(1);
                    view2.setBackgroundResource(R.drawable.pin_code);
                    break;
                case 3:
                    num3 = numbers_list.get(2);
                    view3.setBackgroundResource(R.drawable.pin_code);
                    break;
                case 4:
                    num4 = numbers_list.get(3);
                    view4.setBackgroundResource(R.drawable.pin_code);
                    passCode = num1 + num2 + num3 + num4;
                    if(getPassCode().length() == 2){
                        savePassCode(passCode);
                    } else {
                        matchPassCode();
                    }
                    break;

            }
        }
    }

    private void matchPassCode() {
        if (getPassCode().equals(passCode)) {
            startActivity(new Intent(this, DashboardActivity.class));
            Toast.makeText(this, "1111", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Verification Code Incorrect", Toast.LENGTH_SHORT).show();
        }
    }
    private SharedPreferences.Editor savePassCode(String passCode){
        SharedPreferences preferences = getSharedPreferences("passcode pref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("passcode", passCode);
        editor.commit();

        return editor;
    }
    private String getPassCode(){
        SharedPreferences preferences = getSharedPreferences("passcode pref", Context.MODE_PRIVATE);
        return preferences.getString("passcode","");
    }

    public void LoggedActivity(){
        Intent intent =new Intent(ConfirmPinActivity.this, DashboardActivity.class);
        startActivity(intent);
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        startActivity(new Intent(this, ChangePinActivity.class));
    }
}