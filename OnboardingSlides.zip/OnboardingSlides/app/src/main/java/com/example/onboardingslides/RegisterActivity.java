package com.example.onboardingslides;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class RegisterActivity extends AppCompatActivity {

    private EditText phoneNumber;
    private Button loginBtn;
    private Button biometricBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View windowDecorView = getWindow().getDecorView();
        windowDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        setContentView(R.layout.activity_register);

        phoneNumber = findViewById(R.id.phoneNumber);
        loginBtn = findViewById(R.id.loginBioBtn);
        biometricBtn = findViewById(R.id.btnbiometric);

        loginBtn.setOnClickListener(new View.OnClickListener() {

//            if (EditText.getText().toString().isEmpty()){
//                textView.setText("");
//                Toast.makeText(getActivity(), "Fill the required field", Toast.LENGTH_SHORT).show();
//            } else {
//                textView.setText(editText.getText().toString);
//            }

            @Override
            public void onClick(View v) { RestApiActivity();
            }
        });

        biometricBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {HomeActivity(); }
        });
    }
    public void HomeActivity(){
        Intent intent = new Intent(RegisterActivity.this, BioRegisterActivity.class);
        startActivity(intent);
    }
    public void RestApiActivity(){
        Intent intent = new Intent( RegisterActivity.this, RestApiActivity.class);
        startActivity(intent);
    }
}
