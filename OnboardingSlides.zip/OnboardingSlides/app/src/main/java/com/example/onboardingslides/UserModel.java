package com.example.onboardingslides;

public class UserModel {

    private int imageView;
    private String myName1;
    private String actualName1;
    private String idNumber1;
    private String offis1;
    private String ecle1;
    private String time1;

    public UserModel(int imageView, String myName1, String actualName1, String idNumber1, String offis1, String ecle1, String time1) {
        this.imageView = imageView;
        this.myName1 = myName1;
        this.actualName1 = actualName1;
        this.idNumber1 = idNumber1;
        this.offis1 = offis1;
        this.ecle1 = ecle1;
        this.time1 = time1;
    }

    public int getImageView() {
        return imageView;
    }

    public void setImageView(int imageView) {
        this.imageView = imageView;
    }

    public String getMyName1() {
        return myName1;
    }

    public void setMyName1(String myName1) {
        this.myName1 = myName1;
    }

    public String getActualName1() {
        return actualName1;
    }

    public void setActualName1(String actualName1) {
        this.actualName1 = actualName1;
    }

    public String getIdNumber1() {
        return idNumber1;
    }

    public void setIdNumber1(String idNumber1) {
        this.idNumber1 = idNumber1;
    }

    public String getOffis1() {
        return offis1;
    }

    public void setOffis1(String offis1) {
        this.offis1 = offis1;
    }

    public String getEcle1() {
        return ecle1;
    }

    public void setEcle1(String ecle1) {
        this.ecle1 = ecle1;
    }

    public String getTime1() {
        return time1;
    }

    public void setTime1(String time1) {
        this.time1 = time1;
    }
}
