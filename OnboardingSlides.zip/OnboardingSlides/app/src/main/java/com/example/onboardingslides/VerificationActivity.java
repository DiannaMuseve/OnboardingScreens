package com.example.onboardingslides;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class VerificationActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btnContinue;



    EditText view1, view2, view3, view4;
    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9;
    ImageButton btnx;

    ArrayList<String> numbers_list = new ArrayList<>();
    String passCode ="";
    String num1,num2,num3,num4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View windowDecorView = getWindow().getDecorView();
        windowDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        setContentView(R.layout.activity_verification);
        initializeComponents();

        btnContinue = findViewById(R.id.btnContinue);

        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangePinActivity();
            }
        });
}
    private void initializeComponents() {
        view1 = findViewById(R.id.view1);
        view2 = findViewById(R.id.view2);
        view3 = findViewById(R.id.view3);
        view4 = findViewById(R.id.view4);

        btn0 = findViewById(R.id.btn0);
        btnx = findViewById(R.id.btnx);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);

        btn0.setOnClickListener(this);
        btnx.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn0:
                inputCode("0");
                break;
            case R.id.btnx:
                deletePressed();
                break;
            case R.id.btn1:
                inputCode("1");
                break;
            case R.id.btn2:
                inputCode("2");
                break;
            case R.id.btn3:
                inputCode("3");
                break;
            case R.id.btn4:
                inputCode("4");
                break;
            case R.id.btn5:
                inputCode("5");
                break;
            case R.id.btn6:
                inputCode("6");
                break;
            case R.id.btn7:
                inputCode("7");
                break;
            case R.id.btn8:
                inputCode("8");
                break;
            case R.id.btn9:
                inputCode("9");
                break;
        }
    }

    private void inputCode(String number) {
        if (view1.getText().toString().isEmpty()){
            view1.setText(number);
            numbers_list.add(number);
            passNumber(numbers_list);
        } else if (view2.getText().toString().isEmpty()){
            view2.setText(number);
            numbers_list.add(number);
            passNumber(numbers_list);
        } else if (view3.getText().toString().isEmpty()) {
            view3.setText(number);
            numbers_list.add(number);
            passNumber(numbers_list);
        } else if (view4.getText().toString().isEmpty()) {
            view4.setText(number);
            numbers_list.add(number);
            passNumber(numbers_list);
        }
    }

    public void deletePressed(){
        if (!view4.getText().toString().isEmpty()){
            view4.setText("");
        } else if (!view3.getText().toString().isEmpty()){
            view3.setText("");
        } else if (!view2.getText().toString().isEmpty()) {
            view2.setText("");
        } else if (!view1.getText().toString().isEmpty()) {
            view1.setText("");
        }
    }

    private void passNumber(ArrayList<String> numbers_list) {
        if (numbers_list.size() == 0){
            view1.setBackgroundResource(R.drawable.linesss);
            view2.setBackgroundResource(R.drawable.linesss);
            view3.setBackgroundResource(R.drawable.linesss);
            view4.setBackgroundResource(R.drawable.linesss);
        } else {
            switch (numbers_list.size()){
                case 1:
                    num1 = numbers_list.get(0);
                   // view1.setBackgroundResource(R.drawable.pin_code);
                    break;
                case 2:
                    num2 = numbers_list.get(1);
                    //view2.setBackgroundResource(R.drawable.pin_code);
                    break;
                case 3:
                    num3 = numbers_list.get(2);
                   // view3.setBackgroundResource(R.drawable.pin_code);
                    break;
                case 4:
                    num4 = numbers_list.get(3);
                   // view4.setBackgroundResource(R.drawable.pin_code);
                    passCode = num1 + num2 + num3 + num4;
                    if(getPassCode().length() == 0){
                        savePassCode(passCode);
                    } else {
                        matchPassCode();
                    }
                    break;

            }
        }
    }

    private void matchPassCode() {
        if (getPassCode().equals(passCode)) {
            startActivity(new Intent(this, DashboardActivity.class));
            Toast.makeText(this, "1111", Toast.LENGTH_SHORT).show();
        } else {
            startActivity(new Intent(this, ChangePinActivity.class));
            Toast.makeText(this, "Verification Code Incorrect", Toast.LENGTH_SHORT).show();
        }
    }

    private SharedPreferences.Editor savePassCode(String passCode){
        SharedPreferences preferences = getSharedPreferences("passcode pref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("passcode", passCode);
        editor.commit();

        return editor;
    }
    private String getPassCode(){
        SharedPreferences preferences = getSharedPreferences("passcode pref", Context.MODE_PRIVATE);
        return preferences.getString("passcode","");
    }
    public void ChangePinActivity(){
        Intent intent = new Intent(VerificationActivity.this, ChangePinActivity.class);
        startActivity(intent);
    }
}