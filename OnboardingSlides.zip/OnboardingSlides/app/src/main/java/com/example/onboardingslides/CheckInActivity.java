package com.example.onboardingslides;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class CheckInActivity extends AppCompatActivity {

    private Button backtoHome;
    private ImageView backarrow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View windowDecorView = getWindow().getDecorView();
        windowDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        setContentView(R.layout.activity_check_in);


        backtoHome = findViewById(R.id.backtoHome);
        backarrow = findViewById(R.id.backarrow);

        backtoHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SearchActivity();

            }
        });
        backarrow.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {

                SearchActivity();
            }
        });
    }

    public void SearchActivity() {
        Intent intent = new Intent(CheckInActivity.this, DashboardActivity.class);
        startActivity(intent);
    }


}