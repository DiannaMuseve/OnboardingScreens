package com.example.onboardingscreen;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class UserAdapter  extends RecyclerView.Adapter<UserAdapter.UserAdapterVh> {

    public List<UserModel> userModelList = new ArrayList<>();
           public Context context;

    public UserAdapter(List<UserModel> userModel, Context context){
        this.userModelList = userModel;
        this.context = context;

    }
    public void setFilteredList(List<UserModel> filteredList){
        this.userModelList = filteredList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public UserAdapterVh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.my_row, parent, false);
        return new UserAdapterVh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserAdapterVh holder, int position) {

        UserModel userModel = userModelList.get(position);
        int imageView = userModel.getImageView();
        String myName1 = userModel.getMyName1();
        String actualName1 = userModel.getActualName1();
        String idNumber1 = userModel.getIdNumber1();
        String offis1 = userModel.getOffis1();
        String ecle1 = userModel.getEcle1();
        String time1 = userModel.getTime1();


        holder.imageView.setImageResource(imageView);
        holder.myName1.setText(myName1);
        holder.actualName1.setText(actualName1);
        holder.idNumber1.setText(idNumber1);
        holder.offis1.setText(offis1);
        holder.ecle1.setText(ecle1);
        holder.time1.setText(time1);


    }

    @Override
    public int getItemCount() {
        return userModelList.size();
    }

    public static class UserAdapterVh extends RecyclerView.ViewHolder {

        private ImageView imageView;
        private TextView myName1;
        private TextView actualName1;
        private TextView idNumber1;
        private TextView offis1;
        private TextView ecle1;
        private TextView time1;

        public UserAdapterVh(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            myName1 = itemView.findViewById(R.id.myName1);
            actualName1 = itemView.findViewById(R.id.actualName1);
            idNumber1 = itemView.findViewById(R.id.idNumber1);
            offis1 = itemView.findViewById(R.id.offis1);
            ecle1 = itemView.findViewById(R.id.ecle1);
            time1 = itemView.findViewById(R.id.time1);

        }
    }

}
