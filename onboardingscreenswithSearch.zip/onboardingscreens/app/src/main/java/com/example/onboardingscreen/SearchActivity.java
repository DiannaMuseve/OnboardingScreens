package com.example.onboardingscreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {


    private SearchView searchView;

    RecyclerView recyclerView1;
    UserAdapter userAdapter;
    List<UserModel> userModelList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        searchView =findViewById(R.id.searchView);
        searchView.clearFocus();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);
                return true;
            }
        });


        recyclerView1 = findViewById(R.id.recyclerView1);
        setData();
        prepareRecyclerView();
    }

    private void filterList(String text) {
        List<UserModel>filteredList = new ArrayList<>();
        for (UserModel userModel : userModelList){
            if (userModel.getActualName1().toLowerCase().contains(text.toLowerCase())){
                filteredList.add(userModel);
            }
        }
        if (filteredList.isEmpty()){
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        } else {
              userAdapter.setFilteredList(filteredList);
        }
    }

    public void setData(){
        userModelList.add(new UserModel(R.drawable.leftarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.rightarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.rightarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.leftarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.leftarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.rightarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.leftarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.rightarrow,"Name","Dennis Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));
        userModelList.add(new UserModel(R.drawable.leftarrow,"Name","Simon Kimani", "ID:23647564","Office", "Eclectics","Today at 8:30 am"));

    }


    public void prepareRecyclerView(){
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false);
        recyclerView1.setLayoutManager((linearLayoutManager));
         preAdapter();
    }

    public void preAdapter(){
        userAdapter = new UserAdapter(userModelList, this);
        recyclerView1.setAdapter(userAdapter);
    }

}