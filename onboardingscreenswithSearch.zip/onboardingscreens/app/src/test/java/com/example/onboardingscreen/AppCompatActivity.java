package com.example.onboardingscreen;

public class AppCompatActivity {
}
