package com.example.onboardingscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class SuccessfulActivity extends AppCompatActivity {

    private Button backtoHome;
    private ImageView backarrow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View windowDecorView = getWindow().getDecorView();
        windowDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        setContentView(R.layout.activity_successful);

        backtoHome = findViewById(R.id.backtoHome);
        backarrow = findViewById(R.id.backarrow);

        backtoHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoggedActivity();

            }
        });
        backarrow.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                LoggedActivity();
            }
        });
    }

    public void LoggedActivity() {
        Intent intent = new Intent(SuccessfulActivity.this, LoggedActivity.class);
        startActivity(intent);
    }


}