package com.example.onboardingscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ConfirmPinActivity extends AppCompatActivity {

    private Button btnContinue;
    private Button btn0;
    private Button btn1;
    private Button btn2;
    private Button btn3;
    private Button btn4;
    private Button btn5;
    private Button btn6;
    private Button btn7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View windowDecorView = getWindow().getDecorView();
        windowDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        setContentView(R.layout.activity_confirmpinpin);

        btnContinue = findViewById(R.id.btnContinue);
        btn1 = findViewById(R.id.btn1);

        btn1.setText("1");





        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoggedActivity();
            }
        });
    }
    public void LoggedActivity(){
        Intent intent =new Intent(ConfirmPinActivity.this, LoggedActivity.class);
        startActivity(intent);
    }
}