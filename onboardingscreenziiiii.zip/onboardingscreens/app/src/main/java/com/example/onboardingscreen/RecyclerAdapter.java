package com.example.onboardingscreen;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    String data1[], data2[], data3[], data4[], data5[],data6[];
    int image[];
    Context context;



    public RecyclerAdapter(Context ct, String s1[], String s2[], String s3[],String s4[],String s5[], String s6[], int img[]){

        context = ct;
        data1 = s1;
        data2 = s2;
        data3 = s3;
        data4 = s4;
        data5 = s5;
        data6 = s6;
        image = img;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);

        return new RecyclerAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
       holder.myName1.setText(data1[position]);
        holder.actualName1.setText(data2[position]);
        holder.idNumber1.setText(data3[position]);
        holder.offis1.setText(data4[position]);
        holder.ecle1.setText(data5[position]);
        holder.time1.setText(data6[position]);
        holder.imageView.setImageResource(image[position]);
    }

    @Override
    public int getItemCount() {
        return image.length;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView myName1, actualName1,idNumber1,offis1,ecle1,time1;
        ImageView imageView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            myName1 = itemView.findViewById(R.id.myName1);
            actualName1 = itemView.findViewById(R.id.actualName1);
            idNumber1 = itemView.findViewById(R.id.idNumber1);
            offis1 = itemView.findViewById(R.id.offis1);
            ecle1 = itemView.findViewById(R.id.ecle1);
            time1 = itemView.findViewById(R.id.time1);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}
