package com.example.onboardingscreen;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;


import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {

    private EditText phoneNumber;
    private Button loginBtn;
    private Button biometricBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View windowDecorView = getWindow().getDecorView();
        windowDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        setContentView(R.layout.activity_main1);
        //setContentView(R.layout.activity_logged_in);

        phoneNumber = findViewById(R.id.phoneNumber);
        loginBtn = findViewById(R.id.loginBioBtn);
        biometricBtn = findViewById(R.id.btnbiometric);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { LoggedActivity();
            }
        });

        biometricBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {HomeActivity(); }
        });
    }
    public void HomeActivity(){
        Intent intent = new Intent(MainActivity.this, HomeActivity.class);
        startActivity(intent);
    }
    public void LoggedActivity(){
        Intent intent = new Intent( MainActivity.this, LoggedActivity.class);
        startActivity(intent);
    }
}
