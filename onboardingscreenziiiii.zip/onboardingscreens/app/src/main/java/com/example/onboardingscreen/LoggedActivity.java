package com.example.onboardingscreen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class LoggedActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    private Button checkIn;
    private Button checkOut;


    String s1[], s2[], s3[],s4[],s5[],s6[];
    int image [] = {R.drawable.rightarrow, R.drawable.leftarrow, R.drawable.leftarrow, R.drawable.rightarrow,R.drawable.rightarrow,R.drawable.rightarrow};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View windowDecorView = getWindow().getDecorView();
        windowDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        setContentView(R.layout.activity_logged);

        checkIn = findViewById(R.id.checkIn);
        checkOut = findViewById(R.id.checkOut);

        checkIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {SuccessfulActivity();

            }
        });
        checkOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {CheckoutActivity();

            }
        });


        recyclerView = findViewById(R.id.recyclerView);

        s1 = getResources().getStringArray(R.array.Header);
        s2 = getResources().getStringArray(R.array.Body);
        s3 = getResources().getStringArray(R.array.Description);
        s4 = getResources().getStringArray(R.array.Header1);
        s5 = getResources().getStringArray(R.array.Body1);
        s6 = getResources().getStringArray(R.array.Description1);

        RecyclerAdapter recyclerAdapter = new RecyclerAdapter(this, s1, s2, s3, s4, s5, s6, image);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
    public void SuccessfulActivity(){
        Intent intent = new Intent(LoggedActivity.this, SuccessfulActivity.class);
        startActivity(intent);
    }
    public void CheckoutActivity(){
        Intent intent = new Intent(LoggedActivity.this, CheckoutActivity.class);
        startActivity(intent);
    }

}